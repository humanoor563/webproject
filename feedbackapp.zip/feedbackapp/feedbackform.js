import React, { useState } from 'react';
import axios from 'axios';

const FeedbackForm = () => {
    const [formData, setFormData] = useState({ name: '', email: '', message: '', rating: 5 });
    const [success, setSuccess] = useState(false);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('http://localhost:5000/api/feedback', formData);
        setFormData({ name: '', email: '', message: '', rating: 5 });
        setSuccess(true);
    };

    return (
        <div>
            <h2>Submit Feedback</h2>
            {success && <p>Thanks for your feedback!</p>}
            <form onSubmit={handleSubmit}>
                <input name="name" placeholder="Name" required value={formData.name} onChange={handleChange} />
                <input name="email" type="email" placeholder="Email" required value={formData.email} onChange={handleChange} />
                <textarea name="message" placeholder="Your feedback" required value={formData.message} onChange={handleChange} />
                <input name="rating" type="number" min="1" max="5" value={formData.rating} onChange={handleChange} />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default FeedbackForm;
