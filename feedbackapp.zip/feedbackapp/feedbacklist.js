import React, { useEffect, useState } from 'react';
import axios from 'axios';

const FeedbackList = () => {
    const [feedbacks, setFeedbacks] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5000/api/feedback').then((response) => {
            setFeedbacks(response.data);
        });
    }, []);

    return (
        <div>
            <h2>Feedbacks</h2>
            <ul>
                {feedbacks.map((feedback) => (
                    <li key={feedback._id}>
                        <strong>{feedback.name}</strong>: {feedback.message} (Rating: {feedback.rating})
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default FeedbackList;
